These files are from the original STM stm32cubef4.zip (v1.4.0) 
archive, the folder:

	STM32Cube_FW_F4_V1.4.0/Drivers/STM32F4xx_HAL_Driver/Inc

